import { config } from 'dotenv';
config();

import '@/ai/flows/achievement-badges.ts';
